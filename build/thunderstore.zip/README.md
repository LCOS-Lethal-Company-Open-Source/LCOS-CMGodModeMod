# CM God Mode Mod

This mod adds God Mode features to the game for the host. These features include:

- unlimited number of days to meet the quota
- unlimited amount of starting credits
- infinite sprinting
- higher jumping
- increased health
- increased movement speed

Code by Christian Marinkovich (@Christian2147 on GitHub)

Default icon by @lilujk on github.