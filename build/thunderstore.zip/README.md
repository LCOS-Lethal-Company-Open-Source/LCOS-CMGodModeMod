# CM God Mode Mod

This mod adds God Mode features to the game. These features include:

- unlimited number of days to meet the quota
- unlimited amount of starting credits
- infinite sprinting
- higher jumping (v0.0.2)
- increased health (v.0.0.2)
- increased movement speed (v0.0.2)

This mod is still a work-in-progress mod!

Created by Christian Marinkovich (@Christian2147 on GitHub)

Default icon by @lilujk on github.